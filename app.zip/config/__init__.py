# 配置模块初始化文件
from app.config.settings import *
from app.config.safety import *